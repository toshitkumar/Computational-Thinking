FOR VARSHA — INTERACTIVE BIRTHDAY SURPRISE ♡
Date: 11 October 2026

HOW TO OPEN
1. Extract this ZIP file.
2. Keep the index.html file and the photos folder together.
3. Double-click index.html to open the website in Chrome or another modern browser.
4. Start by clicking the pink envelope, then enjoy the 11 October reveal and birthday surprise.

PHOTO GARDEN
All 37 photos from your ZIP are included in the photos folder and appear in the website with their own romantic captions.
Use “Add more memories” to add extra photos from your computer. “Clear added photos” removes only the photos you add, not the original 37 memories.

NOTES
The gentle melody starts only when the music button is clicked.
The website works locally; it is not yet published to a public URL.
